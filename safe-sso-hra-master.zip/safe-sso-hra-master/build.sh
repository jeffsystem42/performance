cd src
javac -cp "../lib/*" com/socgen/sso/login/module/*
jar cf sso.jar com/socgen/sso/login/module/*
mv sso.jar ..
