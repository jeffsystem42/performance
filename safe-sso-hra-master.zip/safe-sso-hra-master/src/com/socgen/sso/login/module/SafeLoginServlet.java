package com.socgen.sso.login.module;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hraccess.logging.Log;
import com.hraccess.logging.LogFactory;
import com.hraccess.openhr.security.UserDescription;
import com.hraccess.webapp.util.Encoder;

public class SafeLoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected final Log logger = LogFactory.getLog(getClass().getName());

	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException {

		// on verifie si l'utilisation est deja connecte
		// c'est a dire avec un userdescription dans la session

		UserDescription userdescription = (UserDescription) request.getSession().getAttribute("userdescription");

		// controles a faire

		if (userdescription == null) {

			logger.info("utilisateur non connecte");
			
			// on recupere le header http dans la requete
//			logger.debug("Recuperation du header Rtfe");
//			String gid = request.getHeader("sgtssid");
//			logger.debug("gid:" + gid);
			
			
			// on construit le userdescription hra avec les infos du header
			// et on  l ajoute a la session hra-pace
			userdescription = new UserDescription();
			userdescription.setLoginId("1003686308");
			request.getSession().setAttribute("userdescription", userdescription );
			logger.info("userdescription mis en session hra-space");
			
			// on encode l objet userdescription en UTF8 pour le passer dans l'url
			final String encodeUserDescription  = URLEncoder.encode(Encoder.encode(userdescription),"UTF-8");
			logger.info("USER DESCRIPTION :" + encodeUserDescription);
			//logger.debug("userdescription encode pour transmission a openhr via url");
			
			// on genere le lien de redirection
			String url_initiale = request.getRequestURL().toString();
			logger.info("url_initiale:" + url_initiale);
			StringBuffer url_sso = new StringBuffer(url_initiale);
			url_sso.append("&userdescription=" + encodeUserDescription);
			url_sso.append("&loginModuleHint=SafeLoginModule");
			url_sso.append("&accessibility=0");
			logger.info("url_sso:" + url_sso);
			response.sendRedirect(url_sso.toString());

		} else {
			logger.info("utilisateur deja connecte, on ne fait rien");
		}
	}

}
