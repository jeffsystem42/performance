package com.socgen.sso.login.module;

import org.apache.commons.configuration.Configuration;

import com.hraccess.logging.Log;
import com.hraccess.logging.LogFactory;
import com.hraccess.openhr.security.UserDescription;
import com.hraccess.portal.accessibility.AccessibilityMode;
import com.hraccess.portal.login.HRPortalRequest;
import com.hraccess.portal.login.LoginRequest;
import com.hraccess.portal.login.LoginRequestBuilder;
import com.hraccess.portal.login.LoginRequestBuilderException;

import org.apache.commons.lang.StringUtils;

public class SafeLoginRequestBuilder implements LoginRequestBuilder {

	protected final Log logger = LogFactory.getLog(getClass().getName());

	@Override
	public LoginRequest createLoginRequest(HRPortalRequest request) throws LoginRequestBuilderException {
		// TODO Auto-generated method stub

		logger.info("DANS LE CREATE_LOGIN_REQUEST");
		UserDescription userdescription = new UserDescription();

		logger.info("HEADERS:" + request.getHeaderMap().toString());
		String sgigg;
		
		try {
			// sgigg = request.getParameterValue("sgigg");
			sgigg = request.getHeaderValue("sgigg");
		} catch (Exception e) {
			logger.info("pas de sgigg dans les headers, on renvoie blank");
			sgigg = "";
		}

		if (!StringUtils.isNotBlank(sgigg)) {

			return null;

		} else {

			userdescription.setLoginId(sgigg);

			String loginModuleHint = "SafeLoginModule";

			AccessibilityMode accessibilityMode = AccessibilityMode.getFromValue("0");
			LoginRequest loginRequest = new LoginRequest(userdescription, accessibilityMode, loginModuleHint);

			return loginRequest;
		}
	}

	@Override
	public void init(Configuration arg0) {
		// TODO Auto-generated method stub

	}

}
