package com.socgen.sso.login.module;

import java.sql.ResultSet; 
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hraccess.dispatcher.service.login.AbstractLoginModule;
import com.hraccess.logging.Log;
import com.hraccess.logging.LogFactory;
import com.hraccess.openhr.exception.SecurityException;
import com.hraccess.openhr.security.Notifications;
import com.hraccess.openhr.security.Role;
import com.hraccess.openhr.security.UserDescription;

public class SafeLoginModule extends AbstractLoginModule {
	
	protected final Log logger = LogFactory.getLog(getClass().getName());
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return this.jdbcTemplate;
	}
	
			

	@Override
	public Notifications process(UserDescription userdescription) throws SecurityException {
		
		logger.info("Entree dans la methode process du login module hr");
		// TODO Auto-generated method stub
		
		logger.info("  --LE USER DESCRIPTION AU DEBUT DE LA METHODE PROCESS =" + userdescription);
		//On fait une requete en base de donnes pour recuperer le loginId en fonction du gid (header)
		String sql1 = "Select b.lognid " +
				     "From zy4i b, zyy5 a,  zyes d " + 
				     "where a.nudoss = b.nudoss " +
				     "and b.nudoss = d.nudoss " +
				     "and d.datent <= sysdate " +
				     "and d.datsor >= sysdate " +
				     "and a.IGGCDN = '" + userdescription.getLoginId() + "'";
		
		String loginId = (String) jdbcTemplate.queryForObject(sql1, String.class);
		
		logger.info("  --LE LOGIN ID DE LA REQUETE EST = "+ loginId);
			
		userdescription.reset();
		userdescription.setLanguage('F');
		userdescription.setLoginId(loginId);
		// Ajouter les roles de l utilisateur (tables zy09)
					
//		String sql2 = "Select a.rolmod,a.rolval " +
//			     "From zy09 a, zy4i b " + 
//			     "where a.nudoss = b.nudoss " +
//			     "and b.login = " + loginId;
//		
		
		// pas tester au run, pas sur que cela marche ;-)
		/* ArrayList<Role> listRoles = new ArrayList<Role>();
		listRoles = (ArrayList<Role>) jdbcTemplate.query(sql2, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 Role role = new Role();
				 role.setTemplate(rs.getString("ROLMOD"));
				 role.setParameter(rs.getString("ROLVAL"));
				 return role;
			 }
		});
		
		userdescription.addRoles(listRoles);
		*/
		
		return new Notifications();
	}
	
	
	
}
